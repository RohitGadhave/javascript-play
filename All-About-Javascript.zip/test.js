console.log('Test Run Start');



console.log(global);





console.log('Test Run End');