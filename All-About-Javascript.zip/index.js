console.log('Om Sai Ram');

// require('./Array/array');
// require('./Loops/loops');
// require('./Common/Assignment_Destructuring');
// require('./Common/SpreadOperatorAndRestParameters');
require('./Functions/functions');
