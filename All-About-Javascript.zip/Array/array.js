console.log('Hi i am array');

let arrayOfNumber = [];