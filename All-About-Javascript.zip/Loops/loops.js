for(let i=0;i<9000;i++){
  const sum = addTwonmber(i,i);
  console.log(sum)
}
function addTwonmber(a,b){
  return a+b;
}